Honey Sticky Piston: use honeycombs to craft sticky pistons
===========================================================

Honey Sticky Piston is a quality of life Datapack for Minecraft that lets players
use honeycombs as an alternative to slime balls to craft sticky pistons.

This can make sticky pistons more accessible during early game.

Notes
-----

1. The original recipe based on slime balls is unchanged and remains available.

license
-------

[HoneyStickyPiston Datapack for Minecraft][] by [MeeniMC][] is licensed under [CC BY-NC-SA 4.0][5]

![][1]![][2]![][3]![][4]

Contact me if you have commercial plans.

  [HoneyStickyPiston Datapack for Minecraft]: https://modrinth.com/datapack/honey-sticky-piston
  [MeeniMC]: https://github.com/MeeniMc
  [1]: https://mirrors.creativecommons.org/presskit/icons/cc.svg?ref=chooser-v1
  [2]: https://mirrors.creativecommons.org/presskit/icons/by.svg?ref=chooser-v1
  [3]: https://mirrors.creativecommons.org/presskit/icons/nc.svg?ref=chooser-v1
  [4]: https://mirrors.creativecommons.org/presskit/icons/sa.svg?ref=chooser-v1
  [5]: https://creativecommons.org/licenses/by-nc-sa/4.0
